var anuncio = document.getElementById("div-gpt-ad-portada_rb");
anuncio.style.visibility = 'hidden'